export const FoodSlideShowData = [
    {
        image: '/food_image/0001.jpg'
    },
    {
        image: '/food_image/0002.jpg'
    },
    {
        image: '/food_image/0003.jpg'
    },
    {
        image: '/food_image/0004.jpg'
    },
    {
        image: '/food_image/0005.jpg'
    },
    {
        image: '/food_image/0006.jpg'
    },
    {
        image: '/food_image/0007.jpg'
    },
    {
        image: '/food_image/0008.jpg'
    },
    {
        image: '/food_image/0009.jpg'
    },
    {
        image: '/food_image/0010.jpg'
    },
    {
        image: '/food_image/0011.jpg'
    },
    {
        image: '/food_image/0012.jpg'
    },
    {
        image: '/food_image/0013.jpg'
    },
    {
        image: '/food_image/0014.jpg'
    }
]
